export class FileUploadData {
    ETag: string;
    ServerSideEncryption: string;
    Location: string;
    key: string;
    Key: string;
    Bucket: string;
}