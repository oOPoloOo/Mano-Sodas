import { Body, Controller, Delete, Inject, Post, UsePipes, ValidationPipe } from '@nestjs/common';
import { CreateCameraDto } from 'src/cameras/dto/createCamera.dto';
import { CamerasService } from 'src/cameras/services/cameras/cameras.service';
// import { DevicesService } from 'src/devices/services/devices/devices.service';

@Controller('cameras')
export class CamerasController {
    constructor(
        @Inject('CAMERA_SERVICE')
        private readonly camerasService: CamerasService,
        // @Inject('DEVICE_SERVICE')
        // private readonly deviceService: DevicesService,
    ) { }
   
    // @Post('create')
    // @UsePipes(ValidationPipe)
    // async createUser(@Body() createCameraDto: CreateCameraDto) {

    //    // const cameraInDB = await this.createCameraDto.findCameraByID(createCameraDto.plantType);
    //     // if (!cameraInDB){
    //     //     return this.camerasService.createCamera(createCameraDto);
    //     // } else {
    //     //     throw new UserAlreadyExists();
    //     // }       
    //     return this.camerasService.createCameraPlant(createCameraDto);
    // }

    @Delete('delete/all')
     deleteAllCameras() {
                      return this.camerasService.deleteAllCameras();        
    }
    @Post('all')
    getAllCameras(){
        return this.camerasService.findAllCmeras();
    }
}
