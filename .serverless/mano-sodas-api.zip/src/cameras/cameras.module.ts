import { Module } from '@nestjs/common';
import { CamerasController } from './controllers/cameras/cameras.controller';
import { CamerasService } from './services/cameras/cameras.service';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Camera } from 'src/typeorm/Camera';
import { Plant } from 'src/typeorm/Plant';



@Module({
  imports: [TypeOrmModule.forFeature([Camera, Plant,])],
  controllers: [CamerasController],
  providers: [
    {
      provide: "CAMERA_SERVICE",
      useClass: CamerasService,
    },  
  ]
})
export class CamerasModule {}
