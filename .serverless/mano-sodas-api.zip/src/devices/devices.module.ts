import { Module } from '@nestjs/common';
import { DevicesService } from './services/devices/devices.service';
import { DevicesController } from './controllers/devices/devices.controller';
import { TypeOrmModule } from '@nestjs/typeorm';
import { MainDevice } from 'src/typeorm/MainDevice';
import { CamerasService } from 'src/cameras/services/cameras/cameras.service';
import { Camera } from 'src/typeorm/Camera';
import { Plant } from 'src/typeorm/Plant';

@Module({
  imports: [TypeOrmModule.forFeature([MainDevice, Camera, Plant])],
  controllers: [DevicesController],
  providers: [
    {
      provide: "DEVICE_SERVICE",
      useClass: DevicesService,
    },
    {
      provide: "CAMERA_SERVICE",
      useClass: CamerasService,
    },
  ]
})
export class DevicesModule {}
