import { Inject, Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { CamerasService } from 'src/cameras/services/cameras/cameras.service';
import { CreateDeviceCameraDto } from 'src/devices/dto/CreateDeviceCamera.dto';
import { Camera } from 'src/typeorm/Camera';
import { MainDevice as DeviceEntity } from 'src/typeorm/MainDevice';
import { Repository } from 'typeorm';

@Injectable()
export class DevicesService {

    constructor(
        @InjectRepository(DeviceEntity) private readonly deviceRepository: Repository<DeviceEntity>,
        @Inject('CAMERA_SERVICE') private readonly camerasService: CamerasService) { }

    async createDevice(createDeviceCameraDto: CreateDeviceCameraDto) {
    
        //array of type photo entity
        let newCameras: Array<Camera> = []; 

        //Creating multiple camera/plant entities
        for (let camSerial of createDeviceCameraDto.camserialNumber) {
             let camera =  await this.camerasService.createCameraPlant(camSerial); 
            newCameras.push(camera);
        }
        
        const newDevice = this.deviceRepository.create(
            {
                serialNumber: createDeviceCameraDto.serialNumber,
            });
        newDevice.cameras = newCameras;
        return this.deviceRepository.save(newDevice);
    }

    findDeviceBySerial(serial: string) {

        return this.deviceRepository.findOne({
            where: {
                serialNumber: serial
            }
        });
    }
    

    findAllDevices() {
        return this.deviceRepository.find();
    }

    async deleteAllDevices() {

        const allDevices = await this.deviceRepository.find();
        // const allUsersId[] = allUsers.map(user => ({ value: user.id}));
        allDevices.forEach(device => {
            this.deviceRepository.delete(device);
        });
        return allDevices;
    }
}
